"""Turn an uploaded reference document into a reusable design.

The brief is explicit: a reference tells us *how* the provider's documents look,
never what they say. So we read the reference's structure — page size, margins,
type family and size, colour hierarchy and header treatment — and rebuild a
clean letterhead in that style around the *user's own* business details. We
never copy the reference's wording, its client or its prices, so an uploaded
document can never leak another business's content into a new quotation.
"""

from __future__ import annotations

import statistics

import pymupdf

from services.designs import Design, DesignTokens, PAGE_H, PAGE_W

_FAMILY_HINTS = (
    ("times", "Times New Roman"),
    ("georgia", "Georgia"),
    ("garamond", "Georgia"),
    ("cambria", "Georgia"),
    ("book", "Georgia"),
    ("arial", "Arial"),
    ("helvetica", "Arial"),
    ("roboto", "Arial"),
    ("calibri", "Segoe UI"),
    ("segoe", "Segoe UI"),
    ("courier", "Courier New"),
)

_DARK = 0.5
_WHITEISH = 0.9


def _family_of(name: str) -> str:
    lowered = (name or "").lower()
    for hint, family in _FAMILY_HINTS:
        if hint in lowered:
            return family
    return "Arial"


def _hex_of(color: int) -> str:
    color = int(color) & 0xFFFFFF
    return f"#{color >> 16 & 0xFF:02X}{color >> 8 & 0xFF:02X}{color & 0xFF:02X}"


def _luminance(color: int) -> float:
    color = int(color) & 0xFFFFFF
    r, g, b = (color >> 16 & 0xFF) / 255, (color >> 8 & 0xFF) / 255, (color & 0xFF) / 255
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _dominant(values, *, dark: bool = False, exclude_white: bool = True) -> int | None:
    filtered = []
    for value in values:
        if exclude_white and _luminance(value) > _WHITEISH:
            continue
        if dark and _luminance(value) > _DARK:
            continue
        filtered.append(int(value))
    if not filtered:
        return None
    try:
        return statistics.mode(filtered)
    except statistics.StatisticsError:
        return filtered[0]


def count_pages(pdf_bytes: bytes) -> int:
    try:
        doc = pymupdf.open(stream=pdf_bytes, filetype="pdf")
    except Exception:
        return 0
    try:
        return int(doc.page_count)
    finally:
        doc.close()


def analyze_reference(pdf_bytes: bytes, *, name: str = "Reference design",
                      reference_of: str = "") -> Design:
    doc = pymupdf.open(stream=pdf_bytes, filetype="pdf")
    try:
        page = doc.load_page(0)
        page_w, page_h = page.rect.width, page.rect.height
        spans = _collect_spans(page)
        drawings = _collect_drawings(page)

        families = [s["family"] for s in spans]
        body_family = _mode(families) or "Arial"
        heading_family = body_family
        if spans:
            heading_family = _family_of(max(spans, key=lambda s: s["size"]).get("font", ""))

        sizes = [s["size"] for s in spans if 7.5 <= s["size"] <= 16]
        body_size = _clamp(statistics.median(sizes) if sizes else 10.5, 9.0, 12.5)

        body_colors = [s["color"] for s in spans if s["size"] <= body_size * 1.1]
        primary = _dominant(body_colors, dark=True) or _dominant(
            [s["color"] for s in spans], dark=True
        ) or 0x1B1B1B

        fill_colors = [d["color"] for d in drawings if d["kind"] == "fill"]
        accent = (
            _dominant([s["color"] for s in spans if s["color"] != primary])
            or _dominant(fill_colors)
            or primary
        )

        header_style = _header_style(drawings, spans, body_size, page_w, page_h)
        header_height = _header_height(spans, body_size)
        margin_top = _clamp(header_height + 78, 90, page_h * 0.3)
        margin_bottom = _clamp(page_h - _max_bottom(spans) - 24, 40, 96)
        if _has_full_page_image(page):
            body_spans = [
                span for span in spans
                if span["bbox"][1] >= max(60.0, margin_top - 24.0)
                and span["bbox"][3] < page_h * 0.82
            ]
            if body_spans:
                margin_top = _clamp(
                    min(span["bbox"][1] for span in body_spans) + 9.0,
                    90,
                    page_h * 0.55,
                )
                body_bottom = max(span["bbox"][3] for span in body_spans) + 20.0
                footer_top = page_h - max(96.0, page_h * 0.15)
                content_bottom = min(body_bottom, footer_top)
                margin_bottom = page_h - content_bottom

        tokens = DesignTokens(
            primary=_hex_of(primary),
            accent=_hex_of(accent),
            text=_hex_of(primary),
            muted=_hex_of(_lighten(primary)),
            border="#D9D4C7",
            page_bg="#FFFFFF",
            header_bg="#FFFFFF" if _luminance(primary) > _DARK else _hex_of(primary),
            header_text=_hex_of(primary) if _luminance(primary) > _DARK else "#F5F3EE",
            table_header_bg=_hex_of(primary),
            table_header_text="#FFFFFF",
            zebra="#F7F5F0",
        )

        return Design(
            id="reference",
            name=name,
            description="Rebuilt from an uploaded reference document.",
            kind="reference",
            tokens=tokens,
            font_body=body_family,
            font_heading=heading_family,
            body_size=body_size,
            title_align="center" if header_style == "centered" else "left",
            heading_align="left",
            header_style=header_style,
            header_height=header_height,
            reference_of=reference_of,
            margin_left=_clamp(_min_left(spans) - 6, 24, 90),
            margin_right=_clamp(page_w - _max_right(spans) - 6, 24, 90),
            margin_bottom=margin_bottom,
            margin_top=margin_top,
            page_width=page_w,
            page_height=page_h,
        )
    finally:
        doc.close()


def prepare_template_background(
    pdf_bytes: bytes, *, content_top: float, content_bottom: float,
) -> bytes:
    """Keep master branding while clearing previous text and body-area grid lines."""
    doc = pymupdf.open(stream=pdf_bytes, filetype="pdf")
    try:
        for page in doc:
            cleanup_bottom = min(page.rect.height - 120.0, page.rect.height)
            content_rect = pymupdf.Rect(
                0, content_top, page.rect.width,
                max(content_bottom, cleanup_bottom),
            )
            redactions: list[pymupdf.Rect] = []
            for block in page.get_text("dict").get("blocks", []):
                for line in block.get("lines", []):
                    for span in line.get("spans", []):
                        text = (span.get("text") or "").strip()
                        if not text:
                            continue
                        rect = pymupdf.Rect(span["bbox"])
                        if rect.intersects(content_rect):
                            redactions.append(rect + (-0.6, -0.4, 0.6, 0.4))

            for drawing in page.get_drawings():
                rect = drawing.get("rect")
                if rect is None or not rect.intersects(content_rect):
                    continue
                clipped = rect & content_rect
                fill = drawing.get("fill")
                stroke = drawing.get("color")
                is_dark = any(
                    color is not None and max(color) < 0.1
                    for color in (fill, stroke)
                )
                is_body_box = (
                    clipped.width <= 1.5
                    or clipped.height <= 1.5
                    or (is_dark and rect.width < page.rect.width * 0.88)
                )
                if is_body_box:
                    redactions.append((clipped + (-0.2, -0.2, 0.2, 0.2)) & page.rect)

            for rect in redactions:
                page.add_redact_annot(rect, fill=(1, 1, 1), cross_out=False)
            if redactions:
                page.apply_redactions(images=2, graphics=2)
        return doc.tobytes(garbage=3, deflate=True)
    finally:
        doc.close()


# -- extraction --------------------------------------------------------------


def _collect_spans(page) -> list[dict]:
    spans: list[dict] = []
    for block in page.get_text("dict").get("blocks", []):
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                if not (span.get("text") or "").strip():
                    continue
                spans.append({
                    "font": span.get("font", ""),
                    "family": _family_of(span.get("font", "")),
                    "size": float(span.get("size", 10.0)),
                    "color": int(span.get("color", 0)),
                    "bbox": span.get("bbox", (0, 0, 0, 0)),
                })
    return spans


def _collect_drawings(page) -> list[dict]:
    items: list[dict] = []
    try:
        raw = page.get_drawings()
    except Exception:
        return items
    for drawing in raw:
        rect = drawing.get("rect")
        if rect is None:
            continue
        if drawing.get("fill") is not None:
            items.append({"kind": "fill", "color": _rgb_int(drawing["fill"]), "rect": rect})
        if drawing.get("color") is not None and rect.height < 3:
            items.append({"kind": "rule", "color": _rgb_int(drawing["color"]), "rect": rect})
    return items


def _has_full_page_image(page) -> bool:
    page_area = page.rect.get_area()
    for image in page.get_images(full=True):
        for rect in page.get_image_rects(image[0]):
            if (rect & page.rect).get_area() >= page_area * 0.8:
                return True
    return False


def _rgb_int(seq) -> int:
    r, g, b = (seq + (0, 0, 0))[:3]
    return (int(round(r * 255)) << 16) | (int(round(g * 255)) << 8) | int(round(b * 255))


# -- heuristics --------------------------------------------------------------


def _mode(values):
    if not values:
        return None
    try:
        return statistics.mode(list(values))
    except statistics.StatisticsError:
        return values[0]


def _lighten(color: int) -> int:
    color = int(color) & 0xFFFFFF
    r = int(_clamp((color >> 16 & 0xFF) + 70, 0, 255))
    g = int(_clamp((color >> 8 & 0xFF) + 70, 0, 255))
    b = int(_clamp((color & 0xFF) + 70, 0, 255))
    return r << 16 | g << 8 | b


def _header_height(spans, body_size: float) -> float:
    if not spans:
        return 50.0
    top = min(s["bbox"][1] for s in spans)
    cluster_bottom = max((s["bbox"][3] for s in spans if s["bbox"][1] <= top + body_size * 3.2),
                         default=top + body_size)
    height = (cluster_bottom - top) + 16
    return _clamp(height, 44, 78)


def _header_style(drawings, spans, body_size: float, page_w: float, page_h: float) -> str:
    for item in drawings:
        rect = item["rect"]
        if item["kind"] == "fill" and rect.width > page_w * 0.6 and 24 < rect.height < page_h * 0.25:
            if rect.y0 < page_h * 0.3 and _luminance(item["color"]) <= _DARK:
                return "band"
    for item in drawings:
        rect = item["rect"]
        if item["kind"] in ("fill", "rule") and rect.width > page_w * 0.55 and rect.height <= 4:
            if rect.y0 < page_h * 0.35:
                return "rule"
    if spans:
        top_spans = [s for s in spans if s["bbox"][1] < page_h * 0.18]
        if top_spans:
            centers = [(s["bbox"][0] + s["bbox"][2]) / 2 for s in top_spans]
            if abs(statistics.median(centers) - page_w / 2) < page_w * 0.08:
                return "centered"
    return "rule"


def _min_left(spans) -> float:
    return min((s["bbox"][0] for s in spans), default=60.0)


def _max_right(spans) -> float:
    return max((s["bbox"][2] for s in spans), default=550.0)


def _max_bottom(spans) -> float:
    return max((s["bbox"][3] for s in spans), default=760.0)
